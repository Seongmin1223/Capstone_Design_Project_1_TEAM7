# phone > 2024-06-20 2:01pm
https://universe.roboflow.com/jk-j2fcv/phone-sg8xu

Provided by a Roboflow user
License: CC BY 4.0

