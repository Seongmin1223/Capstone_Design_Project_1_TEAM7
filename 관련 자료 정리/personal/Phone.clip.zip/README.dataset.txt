# Phone > 2022-07-30 1:58am
https://universe.roboflow.com/smhrd-vqntt/phone-f2zw3

Provided by a Roboflow user
License: CC BY 4.0

